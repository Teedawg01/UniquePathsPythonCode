from UniquePath import Program

def main():
    program = Program()

    test_cases = [(3, 7), (3, 2)]

    for m, n in test_cases:
        result = program.uniquePaths(m, n)
        print(f"Input: m = {m}, n = {n}")
        print(f"Output: {result}\n")

if __name__ == "__main__":
    main()